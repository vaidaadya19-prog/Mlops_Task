# MLOps Batch Job — Rolling-Mean Signal Generator

A minimal MLOps-style batch pipeline that computes a rolling-mean signal from OHLCV price data, writes structured metrics JSON, and runs identically in Docker.

---

## Project structure

```
mlops-task/
├── run.py           # Main batch job
├── config.yaml      # Run configuration
├── data.csv         # OHLCV input data (10 000 rows)
├── requirements.txt # Python dependencies
├── Dockerfile       # Container definition
├── metrics.json     # Sample successful-run output
├── run.log          # Sample log from successful run
└── README.md
```

---

## Local run

**Prerequisites:** Python 3.9+

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Run the job
python run.py \
  --input    data.csv \
  --config   config.yaml \
  --output   metrics.json \
  --log-file run.log

# 3. Inspect outputs
cat metrics.json
cat run.log
```

---

## Docker build & run

```bash
# Build the image
docker build -t mlops-task .

# Run (outputs stay inside the container)
docker run --rm mlops-task

# Run and capture outputs on the host
mkdir -p output
docker run --rm -v "$(pwd)/output:/app" mlops-task
# metrics.json and run.log will appear in ./output/
```

Exit code `0` = success, non-zero = failure.

---

## Configuration (`config.yaml`)

| Key     | Type    | Description                                      |
|---------|---------|--------------------------------------------------|
| seed    | int     | numpy random seed for reproducibility            |
| window  | int     | Rolling-mean window size (rows)                  |
| version | string  | Pipeline version tag written to metrics output   |

---

## Processing logic

1. **Load config** — validate `seed`, `window`, `version` are present and correctly typed; set `numpy.random.seed(seed)`.
2. **Load dataset** — validate file exists, is non-empty, and contains a `close` column.
3. **Rolling mean** — `close.rolling(window, min_periods=window).mean()`. The first `window-1` rows produce `NaN` and are excluded from signal computation.
4. **Signal** — `signal = 1 if close > rolling_mean else 0` (for valid rows).
5. **Metrics** — compute `rows_processed` (valid rows), `signal_rate` (mean signal), `latency_ms`; write to JSON.

---

## Example `metrics.json`

```json
{
  "version": "v1",
  "rows_processed": 9996,
  "metric": "signal_rate",
  "value": 0.4991,
  "latency_ms": 18,
  "seed": 42,
  "status": "success"
}
```

> `rows_processed = 9996` because the first 4 rows (window-1 = 4) are excluded from signal computation.

---

## Error output format

```json
{
  "version": "v1",
  "status": "error",
  "error_message": "Description of what went wrong",
  "latency_ms": 5
}
```

Metrics are **always written**, even on failure.

---

## Validation handled

- Missing input file
- Unreadable / malformed CSV
- Empty CSV
- Missing `close` column
- Missing or wrong-typed config keys

---

## Reproducibility

Setting `numpy.random.seed(seed)` from config ensures deterministic output across runs on the same data and config. `latency_ms` will vary by machine but all other fields are deterministic.
