"""
run.py - MLOps batch job: Rolling-mean signal generator for OHLCV data.
Usage:
    python run.py --input data.csv --config config.yaml --output metrics.json --log-file run.log
"""

import argparse
import json
import logging
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
import yaml


# ---------------------------------------------------------------------------
# Logging setup
# ---------------------------------------------------------------------------

def setup_logging(log_file: str) -> logging.Logger:
    """Configure root logger to write to both a file and stdout."""
    logger = logging.getLogger("mlops")
    logger.setLevel(logging.DEBUG)
    fmt = logging.Formatter("%(asctime)s [%(levelname)s] %(message)s", datefmt="%Y-%m-%dT%H:%M:%S")

    # File handler
    fh = logging.FileHandler(log_file, mode="w")
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(fmt)
    logger.addHandler(fh)

    # Console handler (stdout)
    ch = logging.StreamHandler(sys.stdout)
    ch.setLevel(logging.INFO)
    ch.setFormatter(fmt)
    logger.addHandler(ch)

    return logger


# ---------------------------------------------------------------------------
# Config helpers
# ---------------------------------------------------------------------------

REQUIRED_CONFIG_KEYS = {"seed", "window", "version"}


def load_config(config_path: str) -> dict:
    """Load and validate YAML config. Raises ValueError on problems."""
    path = Path(config_path)
    if not path.exists():
        raise FileNotFoundError(f"Config file not found: {config_path}")

    with open(path, "r") as f:
        cfg = yaml.safe_load(f)

    if not isinstance(cfg, dict):
        raise ValueError("Config YAML must be a mapping at the top level.")

    missing = REQUIRED_CONFIG_KEYS - cfg.keys()
    if missing:
        raise ValueError(f"Config missing required keys: {missing}")

    if not isinstance(cfg["seed"], int):
        raise ValueError(f"Config 'seed' must be an integer, got: {type(cfg['seed'])}")
    if not isinstance(cfg["window"], int) or cfg["window"] < 1:
        raise ValueError(f"Config 'window' must be a positive integer, got: {cfg['window']}")
    if not isinstance(cfg["version"], str):
        raise ValueError(f"Config 'version' must be a string, got: {type(cfg['version'])}")

    return cfg


# ---------------------------------------------------------------------------
# Dataset helpers
# ---------------------------------------------------------------------------

def load_dataset(input_path: str) -> pd.DataFrame:
    """Load and validate OHLCV CSV. Raises on any problem."""
    path = Path(input_path)
    if not path.exists():
        raise FileNotFoundError(f"Input file not found: {input_path}")

    try:
        df = pd.read_csv(path)
    except Exception as exc:
        raise ValueError(f"Failed to parse CSV: {exc}") from exc

    if df.empty:
        raise ValueError("Input CSV is empty.")

    if "close" not in df.columns:
        raise ValueError(f"Required column 'close' missing. Columns found: {list(df.columns)}")

    if df["close"].isnull().all():
        raise ValueError("Column 'close' contains only null values.")

    return df


# ---------------------------------------------------------------------------
# Processing
# ---------------------------------------------------------------------------

def compute_signal(df: pd.DataFrame, window: int) -> pd.DataFrame:
    """
    Compute rolling mean and binary signal on the 'close' column.

    Strategy for the first (window-1) rows:
        The rolling mean is NaN for those rows (min_periods=window).
        We exclude them from signal computation — signal stays NaN.
        rows_processed and signal_rate are calculated over valid rows only.
    """
    df = df.copy()
    df["rolling_mean"] = df["close"].rolling(window=window, min_periods=window).mean()

    # Signal defined only where rolling_mean is available
    valid = df["rolling_mean"].notna()
    df.loc[valid, "signal"] = (df.loc[valid, "close"] > df.loc[valid, "rolling_mean"]).astype(int)
    df.loc[~valid, "signal"] = np.nan

    return df


# ---------------------------------------------------------------------------
# Metrics / output
# ---------------------------------------------------------------------------

def write_metrics(output_path: str, payload: dict) -> None:
    """Write metrics dict as pretty-printed JSON."""
    with open(output_path, "w") as f:
        json.dump(payload, f, indent=2)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="MLOps rolling-mean signal job")
    parser.add_argument("--input",    required=True, help="Path to input CSV (OHLCV)")
    parser.add_argument("--config",   required=True, help="Path to YAML config file")
    parser.add_argument("--output",   required=True, help="Path to output metrics JSON")
    parser.add_argument("--log-file", required=True, dest="log_file", help="Path to log file")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    logger = setup_logging(args.log_file)

    start_time = time.time()
    logger.info("=== Job started ===")

    version = "unknown"  # populated after config load

    try:
        # ------------------------------------------------------------------
        # 1) Load + validate config
        # ------------------------------------------------------------------
        logger.info("Loading config from: %s", args.config)
        cfg = load_config(args.config)
        version  = cfg["version"]
        seed     = cfg["seed"]
        window   = cfg["window"]
        logger.info("Config loaded — version=%s | seed=%d | window=%d", version, seed, window)

        # Set global seed for reproducibility
        np.random.seed(seed)
        logger.debug("numpy random seed set to %d", seed)

        # ------------------------------------------------------------------
        # 2) Load + validate dataset
        # ------------------------------------------------------------------
        logger.info("Loading dataset from: %s", args.input)
        df = load_dataset(args.input)
        logger.info("Dataset loaded — %d rows, columns: %s", len(df), list(df.columns))

        # ------------------------------------------------------------------
        # 3) Rolling mean
        # ------------------------------------------------------------------
        logger.info("Computing rolling mean with window=%d", window)
        df = compute_signal(df, window)
        valid_rows = df["signal"].notna().sum()
        skipped    = len(df) - valid_rows
        logger.info("Rolling mean computed — %d valid rows, %d skipped (warm-up)", valid_rows, skipped)

        # ------------------------------------------------------------------
        # 4) Signal (already computed in compute_signal)
        # ------------------------------------------------------------------
        logger.info("Binary signal generated (1 if close > rolling_mean, else 0)")

        # ------------------------------------------------------------------
        # 5) Metrics + timing
        # ------------------------------------------------------------------
        signal_rate    = float(df["signal"].mean())          # mean over valid rows
        rows_processed = int(valid_rows)
        latency_ms     = int((time.time() - start_time) * 1000)

        metrics = {
            "version":        version,
            "rows_processed": rows_processed,
            "metric":         "signal_rate",
            "value":          round(signal_rate, 4),
            "latency_ms":     latency_ms,
            "seed":           seed,
            "status":         "success",
        }

        write_metrics(args.output, metrics)
        logger.info("Metrics: rows_processed=%d | signal_rate=%.4f | latency_ms=%d",
                    rows_processed, signal_rate, latency_ms)
        logger.info("Metrics written to: %s", args.output)
        logger.info("=== Job finished — status: success ===")

        # Print JSON to stdout (required by Docker spec)
        print(json.dumps(metrics, indent=2))
        return 0

    except Exception as exc:
        latency_ms = int((time.time() - start_time) * 1000)
        logger.error("Job failed: %s", exc, exc_info=True)

        error_payload = {
            "version":       version,
            "status":        "error",
            "error_message": str(exc),
            "latency_ms":    latency_ms,
        }
        try:
            write_metrics(args.output, error_payload)
            logger.info("Error metrics written to: %s", args.output)
        except Exception as write_exc:
            logger.error("Could not write error metrics: %s", write_exc)

        logger.info("=== Job finished — status: error ===")
        print(json.dumps(error_payload, indent=2))
        return 1


if __name__ == "__main__":
    sys.exit(main())
